# Changelog

## v1.1 — 2025-11-03
- Added AVE Schema v1.1 with provenance/signature fields.
- Published SOP v1.1 with KPIs and incident response.
- Introduced Remedies Clause model and pilot MoU draft.
- Added Standards Concordance and Crosswalk tables.
- Seeded reproducibility appendix and logs.
