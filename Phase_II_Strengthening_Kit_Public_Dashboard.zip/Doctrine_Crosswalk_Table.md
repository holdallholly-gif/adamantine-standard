# Doctrine → Mechanism Crosswalk

| Duty/Doctrine | Risk of Non-Compliance | Adamantine Mechanism | Proof Artifact | Forum/Remedy |
|---|---|---|---|---|
| Honour of the Crown | Opaque consultation | Certified Record + AVE timestamp | Hash + DOI | Declaratory + structural interdict |
| s.52 Supremacy | Unpublished criteria | Publication duty + ledger | DOI + AVE ID | Nullity/reading-in |
| Fiduciary Duty | Conflicted decision-making | Provenance + signatures | Ledger provenance | Injunction + reporting |
| Jus Cogens (Genocide) | Duty evasion | Required Certified Records | Chain-of-custody log | Compliance monitoring |
