# Reproducible Verification Appendix

## Environment
- OS: macOS 14.x or Windows 11 (noting PowerShell version)
- Tools: `shasum` (macOS/Linux) or `Get-FileHash` (Windows), `curl`
- Network: HTTPS access to DOI landing pages

## Procedure (Example)
1) Download the artifact from its DOI landing page.
2) Compute SHA-256 on the **downloaded** file.
3) Record result as a JSON line in `repro_log.jsonl`.

### Commands
**macOS/Linux**
```bash
curl -L -o Example_1.pdf "<SOURCE_URL>"
shasum -a 256 Example_1.pdf | awk '{print $1}'
```

**Windows**
```powershell
Invoke-WebRequest -Uri "<SOURCE_URL>" -OutFile "Example_1.pdf"
(Get-FileHash -Algorithm SHA256 Example_1.pdf).Hash
```

## Expected Results
- Independent runs on the same artifact produce identical SHA-256 values.
- Time-to-verify is typically ≤ 2 minutes.
